import os
import pandas as pd
import torch
import numpy as np
from torch_geometric.data import HeteroData

# ---------- ID Mapping ----------
def build_all_id_mappings(df, suffix="_enc"):
    id_mappings = {}
    for col in df.columns:
        if col.endswith(suffix):
            raw_col = col.replace(suffix, '')
            if raw_col in df.columns:
                mapping = df[[col, raw_col]].drop_duplicates().sort_values(col)
                id_mappings[col] = mapping.set_index(col)[raw_col].to_dict()
            else:
                print(f"Warning: No raw column found for {col}")
    return id_mappings



def save_id_mappings(id_mappings, base_path="graph_export/id_mappings"):
    os.makedirs(base_path, exist_ok=True)
    for enc_col, mapping in id_mappings.items():
        raw_col = enc_col.replace("_enc", "")
        df = pd.DataFrame(list(mapping.items()), columns=[enc_col, raw_col])
        df.to_csv(os.path.join(base_path, f"{enc_col}_map.csv"), index=False)



# ---------- Nodes ----------
def save_node_features(
    data, node_type, id_column_name, filename, 
    id_mapping=None, base_path="graph_export/nodes", composite_name_map=None
):
    if composite_name_map is None:
        composite_name_map = {}

    encoded_path = base_path
    rawvar_path = base_path + "_rawvar"
    os.makedirs(encoded_path, exist_ok=True)
    os.makedirs(rawvar_path, exist_ok=True)

    x = data[node_type].x.cpu().numpy()

    # Use stored feature names if available, else use numbered columns
    feature_names = getattr(
        data[node_type], "feature_names", [f"feat{i}" for i in range(x.shape[1])]
    )
    df = pd.DataFrame(x, columns=feature_names)

    # ---- Encoded version ----
    encoded_df = df.copy()
    encoded_df[id_column_name] = encoded_df.index
    encoded_df.to_csv(os.path.join(encoded_path, filename), index=False)

    # ---- Raw values version ----
    rawvar_df = df.copy()

    if id_mapping:
        # **Force alignment: ensure index = encodings**
        rawvar_df[id_column_name] = rawvar_df.index
        mapped_ids = rawvar_df[id_column_name].map(id_mapping)

        if mapped_ids.notna().all() and isinstance(mapped_ids.iloc[0], tuple):
            # Composite mapping: expand into multiple columns
            col_base = id_column_name.replace("_enc", "")
            split_names = composite_name_map.get(
                col_base, [f"{col_base}_{i}" for i in range(len(mapped_ids.iloc[0]))]
            )
            for idx, col_name in enumerate(split_names):
                rawvar_df[col_name] = mapped_ids.apply(lambda t: t[idx])
        else:
            raw_id_col = id_column_name.replace("_enc", "")
            rawvar_df[raw_id_col] = mapped_ids
    else:
        rawvar_df[id_column_name] = rawvar_df.index

    rawvar_df.to_csv(os.path.join(rawvar_path, filename), index=False)




# ---------- Edges ----------

def save_edges(data,edge_type,  src_col, dst_col,  filename,base_path="graph_export/edges",id_mapping=None):
    os.makedirs(base_path, exist_ok=True)
    rawval_path = base_path + "_rawval"
    os.makedirs(rawval_path, exist_ok=True)

    edge_index = data[edge_type].edge_index.cpu().numpy()
    src_type, _, dst_type = edge_type
    src_enc = edge_index[0]
    dst_enc = edge_index[1]

    #  Encoded data save 
    encoded_df = pd.DataFrame({ src_col: src_enc, dst_col: dst_enc })
    encoded_df.to_csv(os.path.join(base_path, filename), index=False)

    #  Raw values version save 
    src = src_enc
    dst = dst_enc
    if id_mapping:
        src_map = id_mapping.get(src_type, {})
        dst_map = id_mapping.get(dst_type, {})
        src = [src_map.get(i, i) for i in src_enc]
        dst = [dst_map.get(i, i) for i in dst_enc]

    rawval_df = pd.DataFrame()
    rawval_df[src_col] = src
    rawval_df[dst_col] = dst

    rawval_df.to_csv(os.path.join(rawval_path, filename), index=False)

#---------- Labels ------------

def save_node_labels(data, node_type, label_column_name, id_mapping, filename, base_path="graph_export/labels"):
    """
    Generic function to save node labels for any node type into CSV.

    Args:
        data (HeteroData): The heterogeneous graph.
        node_type (str): Node type in the graph
        label_column_name (str): Label column name
        id_mapping (dict): Mapping from node_id -> original identifier
        filename (str): Output CSV filename.
        base_path (str): Directory where CSV will be saved.
    """
    os.makedirs(base_path, exist_ok=True)

    if not hasattr(data[node_type], "y"):
        raise AttributeError(f"Node type '{node_type}' has no labels (.y)")

    y = data[node_type].y.cpu().numpy()

    # build dynamic column names
    enc_col = f"{node_type}_enc"
    orig_col = node_type
    flag_col = label_column_name

    records = []
    for nid, label in enumerate(y):
        orig_val = id_mapping.get(nid, None)  # original id (string/tuple/etc.)
        records.append({
            enc_col: nid,          # encoded id
            orig_col: orig_val,    # original identifier
            flag_col: label        # label
        })

    df = pd.DataFrame(records, columns=[enc_col, orig_col, flag_col])
    outpath = os.path.join(base_path, filename)
    df.to_csv(outpath, index=False)
    print(f"Saved labels for node '{node_type}' ")


#------------- Edge Features -----------------

def save_edge_features(
    data,
    edge_type,
    edge_features_df,
    id_mappings=None,
    base_path="graph_export/edge_features"):
    
    os.makedirs(base_path, exist_ok=True)
    rawval_path = base_path + "_rawval"
    os.makedirs(rawval_path, exist_ok=True)

    src_type, rel_type, dst_type = edge_type
    edge_index = data[edge_type].edge_index.cpu().numpy()
    src_ids = edge_index[0]
    dst_ids = edge_index[1]

    # ---- Encoded save ----
    encoded_df = pd.DataFrame({
        f"{src_type}_enc": src_ids,
        f"{dst_type}_enc": dst_ids
    })

    id_cols = [f"{src_type}_enc", f"{dst_type}_enc"]
    # Keep only numeric features from the input dataframe
    feature_cols = [col for col in edge_features_df.select_dtypes(include='number').columns
    if col not in id_cols]
    
    encoded_df = pd.concat([encoded_df.reset_index(drop=True),
                            edge_features_df[feature_cols].reset_index(drop=True)], axis=1)

    filename = f"{src_type}__{rel_type}__{dst_type}.csv"
    encoded_df.to_csv(os.path.join(base_path, filename), index=False)

    # ---- Raw values version save ----
    rawval_src = src_ids
    rawval_dst = dst_ids
    if id_mappings:
        rawval_src = [id_mappings.get(src_type, {}).get(i, i) for i in src_ids]
        rawval_dst = [id_mappings.get(dst_type, {}).get(i, i) for i in dst_ids]

    rawval_df = pd.DataFrame()

    # Handle tuple mappings
    if rawval_src and isinstance(rawval_src[0], tuple):
        src_names = [f"{src_type}_{i}" for i in range(len(rawval_src[0]))]
        for idx, name in enumerate(src_names):
            rawval_df[name] = [s[idx] for s in rawval_src]
    else:
        rawval_df[src_type] = rawval_src

    if rawval_dst and isinstance(rawval_dst[0], tuple):
        dst_names = [f"{dst_type}{i}" for i in range(len(rawval_dst[0]))]
        for idx, name in enumerate(dst_names):
            rawval_df[name] = [d[idx] for d in rawval_dst]
    else:
        rawval_df[dst_type] = rawval_dst

    # Add features
    rawval_df = pd.concat([rawval_df.reset_index(drop=True),
                          edge_features_df[feature_cols].reset_index(drop=True)], axis=1)

    rawval_df.to_csv(os.path.join(rawval_path, filename), index=False)

    print(f"Saved encoded edge features to {os.path.join(base_path, filename)}")
    print(f"Saved raw values readable edge features to {os.path.join(rawval_path, filename)}")




# ---------- Load the Graph ----------

import os
import json
import torch
import pandas as pd
from torch_geometric.data import HeteroData

def load_graph_from_csv(base_path="graph_export", dataset="r2p2"):
    """
    Loads a heterogeneous graph from CSVs.
    Automatically merges universal id_mappings (pharmacy, brand, ndc_code)
    with dataset-specific mappings
    """
    data = HeteroData()

    # Load universal mappings (pharmacy, brand, ndc_code)
    # common_map_path = os.path.join(base_path, "id_mappings.json")
    common_map_path = os.path.join("id_mappings.json")
    if os.path.exists(common_map_path):
        with open(common_map_path, "r") as f:
            common_maps = json.load(f)
    else:
        common_maps = {}

    # Load dataset-specific mappings 
    dataset_mapping_dir = os.path.join(base_path, f"{dataset}_id_mappings")
    dataset_maps = {}

    def load_mapping_csv(path):
        df = pd.read_csv(path)
        enc_col = df.columns[0]
        raw_col = df.columns[1] 
        # return raw → enc mapping (consistent with common_maps)
        return {str(row[raw_col]): int(row[enc_col]) for _, row in df.iterrows()}

    if os.path.exists(dataset_mapping_dir):
        for file in os.listdir(dataset_mapping_dir):
            if file.endswith("_map.csv"):
                node_type = file.replace("_enc_map.csv", "")
                if node_type in common_maps:
                    continue
                dataset_maps[node_type] = load_mapping_csv(
                    os.path.join(dataset_mapping_dir, file))

    # Merge mappings
    # Remove duplicates of universal mappings from dataset-specific maps
    for node_type in ["pharmacy", "brand", "ndc_code"]:
        if node_type in dataset_maps:
            del dataset_maps[node_type]

    # Merge: dataset-specific first, then common (common wins if overlap remains)
    id_mappings = {**dataset_maps, **common_maps}

    # Load nodes
    node_dir = os.path.join(base_path, f"{dataset}_nodes")
    if os.path.exists(node_dir):
        node_files = [f for f in os.listdir(node_dir) if f.startswith("nodes_") and f.endswith(".csv")]
        for file in node_files:
            node_type = file[len("nodes_"):-len(".csv")]
            df = pd.read_csv(os.path.join(node_dir, file))

            enc_col = f"{node_type}_enc" if f"{node_type}_enc" in df.columns else None
            if enc_col:
                df = df.set_index(enc_col)

            # --- universal num_nodes if mapping exists ---
            if id_mappings and node_type in id_mappings:
                num_nodes = len(id_mappings[node_type])
                df = df.reindex(range(num_nodes)).fillna(0)
            else:
                if not df.empty:
                    num_nodes = int(df.index.max()) + 1
                    df = df.reindex(range(num_nodes)).fillna(0)
                else:
                    num_nodes = 0

            # select features
            feature_cols = df.select_dtypes(include="number").columns.tolist()
            if not feature_cols:
                # No numeric features, assign dummy ones
                x = torch.ones((num_nodes, 1), dtype=torch.float)
                feature_cols = ["dummy"]
            else:
                x = torch.tensor(df[feature_cols].values, dtype=torch.float)

            data[node_type].x = x
            data[node_type].num_nodes = num_nodes
            data[node_type].feature_names = list(feature_cols)

            print(f"[{dataset}] {node_type}: num_nodes={num_nodes}, features={feature_cols}")


    # Load edges
    
    edge_dir = os.path.join(base_path, f"{dataset}_edges")
    edge_feat_dir = os.path.join(base_path, f"{dataset}_edge_features")

    if os.path.exists(edge_dir):
        edge_files = [f for f in os.listdir(edge_dir) if f.endswith(".csv")]
        for edge_file in edge_files:
            src, rel, dst = edge_file.replace(".csv", "").split("__")
            df = pd.read_csv(os.path.join(edge_dir, edge_file))

            # edge_index
            src_ids = df.iloc[:, 0].astype(int).to_numpy()
            dst_ids = df.iloc[:, 1].astype(int).to_numpy()
            edge_index = torch.tensor([src_ids, dst_ids], dtype=torch.long)
            data[(src, rel, dst)].edge_index = edge_index

            # edge features
            feat_path = os.path.join(edge_feat_dir, edge_file)
            if os.path.exists(feat_path):
                feat_df = pd.read_csv(feat_path)
                # Exclude encoded IDs and edge_index_pos
                ignore_cols = [c for c in feat_df.columns if c.endswith("_enc") or c == "edge_index_pos"]
                # feature_cols = feat_df.select_dtypes(include="number").columns
                feature_cols = [c for c in feat_df.select_dtypes(include="number").columns 
                    if c not in ignore_cols]

                if len(feature_cols) > 0:
                    edge_attr = torch.tensor(feat_df[feature_cols].values, dtype=torch.float)
                    data[(src, rel, dst)].edge_attr = edge_attr
                    data[(src, rel, dst)].feature_names = list(feature_cols)


    # Load labels
    labels_dir = os.path.join(base_path, f"{dataset}_labels")
    if os.path.exists(labels_dir):
        label_files = [f for f in os.listdir(labels_dir) if f.endswith(".csv")]
        for label_file in label_files:
            node_type = label_file.replace("labels_", "").replace(".csv", "")
            df = pd.read_csv(os.path.join(labels_dir, label_file))
            label_col = df.select_dtypes(include="number").columns[-1]
            y = torch.tensor(df[label_col].values, dtype=torch.long)
            data[node_type].y = y
    return data, id_mappings


# Function to ensure correct alignment of ndc codes
def clean_ndc(ndc):
    if pd.isna(ndc):
        return None
    ndc_str = str(ndc).strip()
    ndc_str = ndc_str.split('.')[0]  # drop ".0" if present
    ndc_str = ndc_str.zfill(11)      # pad to 11 digits
    return ndc_str

#################################################################################################
########### Functions related to Merging and loading the merged graphs ##########################
#################################################################################################

def align_features(f1, names1, f2, names2):
    """
    Align two feature matrices by column name.
    Missing columns are zero-padded.
    """
    # union of column names
    all_names = sorted(set(names1) | set(names2))

    def to_aligned(feats, names):
        df = pd.DataFrame(feats.numpy(), columns=names)
        for col in all_names:
            if col not in df.columns:
                df[col] = 0.0
        return torch.tensor(df[all_names].values, dtype=torch.float)

    f1_aligned = to_aligned(f1, names1)
    f2_aligned = to_aligned(f2, names2)
    return f1_aligned, f2_aligned, all_names

def debug_print_graph(g, title="Graph"):
    print(f"\n=== {title} ===")
    print("Node types:")
    for ntype in g.node_types:
        x = g[ntype].x if hasattr(g[ntype], "x") else None
        names = getattr(g[ntype], "feature_names", [])
        if x is not None:
            print(f" {ntype}: shape={x.shape}, features={len(names)}")
            print(f" names={names}")
        else:
            print(f" {ntype}: no features")

    print("\nEdge types:")
    for etype in g.edge_types:
        eidx = g[etype].edge_index
        eattr = getattr(g[etype], "edge_attr", None)
        names = getattr(g[etype], "feature_names", [])
        print(f" {etype}: edges={eidx.shape[1]}")
        if eattr is not None:
            print(f" edge_attr.shape={eattr.shape}, features={len(names)}")
            print(f" names={names}")
        else:
            print(" no edge features")

# Function to save the mappings and labels of merged graph
def save_merged_mappings_labels(
    data,
    id_mappings=None,
    out_dir="graph_export_merged",
    prefix="hetero_graph"):

    # Save ID mappings
    if id_mappings is not None:
        mapping_dir = os.path.join(out_dir, "id_mappings")
        os.makedirs(mapping_dir, exist_ok=True)
        for ntype, mapping in id_mappings.items():
            df = pd.DataFrame(list(mapping.items()), columns=[f"{ntype}_enc",ntype])
            df.to_csv(os.path.join(mapping_dir, f"{ntype}_enc_map.csv"), index=False)
        print(f"ID mappings saved at {mapping_dir}")

    # Save labels for any node that has `.y`
    label_dir = os.path.join(out_dir, "labels")
    os.makedirs(label_dir, exist_ok=True)

    for ntype in data.node_types:
        if hasattr(data[ntype], "y") and data[ntype].y is not None:
            y = data[ntype].y.cpu().numpy()
            df = pd.DataFrame({
                f"{ntype}_enc": range(len(y)),
                f"{ntype}_flag": y
            })
            df.to_csv(os.path.join(label_dir, f"{ntype}_labels.csv"), index=False)
    print(f"Labels saved at {label_dir}")

# Save edge features of the merged graph
# # With (Zero) imputation
# def save_merged_edge_features(
#     data,
#     id_mappings=None,
#     base_path="graph_export_merged/edge_features"
# ):
#     """
#     Save edge features from merged HeteroData.
#     Preserves original feature names (no renaming).
#     """
#     import os
#     import pandas as pd

#     os.makedirs(base_path, exist_ok=True)
#     rawval_path = base_path + "_rawval"
#     os.makedirs(rawval_path, exist_ok=True)

#     for etype in data.edge_types:
#         src_type, rel_type, dst_type = etype
#         fname = f"{src_type}__{rel_type}__{dst_type}.csv"

#         # --- Extract edge_index
#         edge_index = data[etype].edge_index.cpu().numpy()
#         src_ids, dst_ids = edge_index[0], edge_index[1]

#         # --- Extract edge features
#         feature_df = pd.DataFrame()
#         if hasattr(data[etype], "edge_attr") and data[etype].edge_attr is not None:
#             feat = data[etype].edge_attr.cpu().numpy()
#             names = getattr(data[etype], "feature_names", None)
#             if names is None:  # fallback if missing
#                 names = [f"{rel_type}_f{i}" for i in range(feat.shape[1])]
#             feature_df = pd.DataFrame(feat, columns=names)

#         # --- Column naming: avoid collisions for self-edges
#         if src_type == dst_type:
#             src_col = f"{src_type}_src_enc"
#             dst_col = f"{dst_type}_dst_enc"
#         else:
#             src_col = f"{src_type}_enc"
#             dst_col = f"{dst_type}_enc"

#         # --- Combine src, dst, features
#         df = pd.DataFrame({src_col: src_ids, dst_col: dst_ids})
#         df = pd.concat([df.reset_index(drop=True),
#                         feature_df.reset_index(drop=True)], axis=1)

#         # --- Save encoded
#         df.to_csv(os.path.join(base_path, fname), index=False)

#         # --- Save raw values (decode ids if mapping exists)
#         rawval_df = df.copy()
#         if id_mappings:
#             rawval_df[src_type] = [
#                 id_mappings.get(src_type, {}).get(i, i) for i in df[src_col]
#             ]
#             rawval_df[dst_type] = [
#                 id_mappings.get(dst_type, {}).get(i, i) for i in df[dst_col]
#             ]
#         rawval_df.to_csv(os.path.join(rawval_path, fname), index=False)

#         print(f"[{etype}] Saved {len(df)} edges with {len(feature_df.columns)} features")

# No imputation
def save_merged_edge_features(data, id_mappings=None, base_path="graph_export_merged/edge_features"):
    """
    Save edge features from merged HeteroData.
    Deduplicate edges by (src, dst) and preserve NaNs.
    """
    import os
    import pandas as pd
    import numpy as np

    os.makedirs(base_path, exist_ok=True)
    rawval_path = base_path + "_rawval"
    os.makedirs(rawval_path, exist_ok=True)

    for etype in data.edge_types:
        src_type, rel_type, dst_type = etype
        fname = f"{src_type}__{rel_type}__{dst_type}.csv"

        # --- Extract edge_index
        edge_index = data[etype].edge_index.cpu().numpy()
        src_ids, dst_ids = edge_index[0], edge_index[1]

        # --- Extract edge features
        if hasattr(data[etype], "edge_attr") and data[etype].edge_attr is not None:
            feat = data[etype].edge_attr.cpu().numpy()
            names = getattr(data[etype], "feature_names", [f"{rel_type}_f{i}" for i in range(feat.shape[1])])
            feature_df = pd.DataFrame(feat, columns=names)
        else:
            feature_df = pd.DataFrame()

        # --- Column naming: avoid collisions for self-edges
        src_col = f"{src_type}_src_enc" if src_type == dst_type else f"{src_type}_enc"
        dst_col = f"{dst_type}_dst_enc" if src_type == dst_type else f"{dst_type}_enc"

        # --- Combine src, dst, features
        df = pd.DataFrame({src_col: src_ids, dst_col: dst_ids})
        df = pd.concat([df.reset_index(drop=True),
                        feature_df.reset_index(drop=True)], axis=1)

        # --- Deduplicate by (src,dst)
        grouped = df.groupby([src_col, dst_col], as_index=False)
        merged_rows = []
        for _, group in grouped:
            row = [group[src_col].iloc[0], group[dst_col].iloc[0]]
            # Keep original features; preserve NaNs
            for col in feature_df.columns:
                vals = group[col].tolist()
                row.append(vals[0] if vals else np.nan)
            merged_rows.append(row)

        # --- Construct merged DataFrame
        merged_df = pd.DataFrame(merged_rows, columns=[src_col, dst_col] + list(feature_df.columns))

        # --- Save encoded CSV
        merged_df.to_csv(os.path.join(base_path, fname), index=False, na_rep='NaN')

        # --- Save raw values using id_mappings
        rawval_df = merged_df.copy()
        if id_mappings:
            rawval_df[src_type] = [id_mappings.get(src_type, {}).get(i, i) for i in merged_df[src_col]]
            rawval_df[dst_type] = [id_mappings.get(dst_type, {}).get(i, i) for i in merged_df[dst_col]]
        rawval_df.to_csv(os.path.join(rawval_path, fname), index=False, na_rep='NaN')

        print(f"[{etype}] Saved {len(merged_df)} deduplicated edges with {len(feature_df.columns)} features (NaNs preserved)")

# Load the merged graph using all csv outpupts of graph_export_merged
def load_merged_graph_from_csv(base_path):
    from torch_geometric.data import HeteroData
    import os, pandas as pd, torch

    data = HeteroData()

    node_dir = os.path.join(base_path, "nodes")
    edge_dir = os.path.join(base_path, "edges")
    edge_feat_dir = os.path.join(base_path, "edge_features")
    label_dir = os.path.join(base_path, "labels")

    # --- Load nodes ---
    if os.path.exists(node_dir):
        for fname in os.listdir(node_dir):
            if fname.endswith(".csv"):
                ntype = fname.replace(".csv", "")
                if ntype.startswith("nodes_"):
                    ntype = ntype[len("nodes_"):]
                df = pd.read_csv(os.path.join(node_dir, fname))

                # Exclude encoding columns
                feature_cols = [c for c in df.select_dtypes(include="number").columns if not c.endswith("_enc")]
                x = torch.tensor(df[feature_cols].values, dtype=torch.float)
                data[ntype].x = x
                data[ntype].feature_names = feature_cols

    # # --- Load edges ---
    # if os.path.exists(edge_dir):
    #     for fname in os.listdir(edge_dir):
    #         if fname.endswith(".csv"):
    #             src, rel, dst = fname.replace(".csv", "").split("__")
    #             df = pd.read_csv(os.path.join(edge_dir, fname))
    #             edge_index = torch.tensor(df.iloc[:, :2].values.T, dtype=torch.long)
    #             data[(src, rel, dst)].edge_index = edge_index

    #             # edge features
    #             feat_path = os.path.join(edge_feat_dir, fname)
    #             if os.path.exists(feat_path):
    #                 feat_df = pd.read_csv(feat_path)
    #                 # Only numeric columns that are NOT *_enc
    #                 feature_cols = [c for c in feat_df.select_dtypes(include="number").columns if not c.endswith("_enc")]
    #                 if len(feature_cols) > 0:
    #                     data[(src, rel, dst)].edge_attr = torch.tensor(
    #                         feat_df[feature_cols].values, dtype=torch.float
    #                     )
    # --- Load edges ---
    if os.path.exists(edge_dir):
        for fname in os.listdir(edge_dir):
            if fname.endswith(".csv"):
                src, rel, dst = fname.replace(".csv", "").split("__")
                df = pd.read_csv(os.path.join(edge_dir, fname))
                edge_index = torch.tensor(df.iloc[:, :2].values.T, dtype=torch.long)
                data[(src, rel, dst)].edge_index = edge_index

                # edge features
                feat_path = os.path.join(edge_feat_dir, fname)
                if os.path.exists(feat_path):
                    feat_df = pd.read_csv(feat_path)
                    # Only numeric columns that are NOT *_enc
                    feature_cols = [c for c in feat_df.select_dtypes(include="number").columns if not c.endswith("_enc")]
                    if len(feature_cols) > 0:
                        data[(src, rel, dst)].edge_attr = torch.tensor(
                            feat_df[feature_cols].values, dtype=torch.float
                        )
                        # Preserve feature names
                        data[(src, rel, dst)].feature_names = feature_cols


    # --- Load labels ---
    if os.path.exists(label_dir):
        for fname in os.listdir(label_dir):
            if fname.endswith("_labels.csv"):
                ntype = fname.replace("_labels.csv", "")
                df = pd.read_csv(os.path.join(label_dir, fname))
                if f"{ntype}_flag" in df:
                    y = torch.tensor(df[f"{ntype}_flag"].values, dtype=torch.long)
                    data[ntype].y = y
    
    # Checks
    print("\n Load Summary")
    for ntype in data.node_types:
        x_shape = data[ntype].x.shape
        feature_names = getattr(data[ntype], "feature_names", [])
        print(f"Node type: {ntype}, num_nodes={x_shape[0]}, num_features={x_shape[1]}, features={feature_names}")

    for etype in data.edge_types:
        e = data[etype]
        edge_index_shape = e.edge_index.shape
        edge_attr_shape = getattr(e, "edge_attr", None).shape if hasattr(e, "edge_attr") else None
        feature_names = getattr(e, "feature_names", None)
        print(f"Edge type: {etype}, edge_index_shape={edge_index_shape}, edge_attr_shape={edge_attr_shape}, features={feature_names}")


    return data

# Validate the merged graph with the loaded merged graph
def validate_graph(saved_data, reloaded_data):
    """Validate saved vs reloaded graph"""
    print("=== Validation Report ===")
    
    # Node check
    for ntype in saved_data.node_types:
        if ntype not in reloaded_data.node_types:
            print(f"Missing node type {ntype} in reloaded graph!")
            continue
        s, r = saved_data[ntype].x.shape, reloaded_data[ntype].x.shape
        print(f"[Node {ntype}] saved={s}, reloaded={r}")
        
        # Feature names check
        f_saved = getattr(saved_data[ntype], "feature_names", None)
        f_reloaded = getattr(reloaded_data[ntype], "feature_names", None)
        if f_saved is not None or f_reloaded is not None:
            print(f"  feature_names: saved={f_saved}, reloaded={f_reloaded}")

    # Edge check
    for etype in saved_data.edge_types:
        if etype not in reloaded_data.edge_types:
            print(f"Missing edge type {etype} in reloaded graph!")
            continue
        s, r = saved_data[etype].edge_index.shape[1], reloaded_data[etype].edge_index.shape[1]
        print(f"[Edge {etype}] saved={s}, reloaded={r}")

        # Edge features
        ea1 = getattr(saved_data[etype], "edge_attr", None)
        ea2 = getattr(reloaded_data[etype], "edge_attr", None)
        print(f"  edge_attr shapes: saved={None if ea1 is None else ea1.shape}, "
              f"reloaded={None if ea2 is None else ea2.shape}")
        
        # Edge feature names check
        f_saved = getattr(saved_data[etype], "feature_names", None)
        f_reloaded = getattr(reloaded_data[etype], "feature_names", None)
        if f_saved is not None or f_reloaded is not None:
            print(f"  edge_feature_names: saved={f_saved}, reloaded={f_reloaded}")

    # Labels check
    for ntype in saved_data.node_types:
        y1 = getattr(saved_data[ntype], "y", None)
        y2 = getattr(reloaded_data[ntype], "y", None)
        if y1 is not None or y2 is not None:
            print(f"[Labels {ntype}] saved={None if y1 is None else y1.shape}, "
                  f"reloaded={None if y2 is None else y2.shape}")





            