# model.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import HGTConv
from torch_scatter import scatter_mean, scatter_add


class HeteroHGTAnomaly(nn.Module):
    """
    Anomaly score =
      A) node feature reconstruction error
    + B) edge existence reconstruction error
    + C) neighbor deviation (degree-normalized)
    """

    def __init__(self, data, hidden=64, heads=2, layers=2):
        super().__init__()
        self.metadata = data.metadata()
        self.hidden = hidden

        # ---------- Node encoders ----------
        self.node_encoders = nn.ModuleDict()
        self.node_decoders = nn.ModuleDict()

        for ntype in data.node_types:
            in_dim = data[ntype].x.size(1)
            self.node_encoders[ntype] = nn.Linear(in_dim, hidden)
            self.node_decoders[ntype] = nn.Linear(hidden, in_dim)

        # ---------- HGT layers ----------
        self.hgt_layers = nn.ModuleList([
            HGTConv(hidden, hidden, metadata=self.metadata, heads=heads)
            for _ in range(layers)
        ])

        # ---------- Edge scorer ----------
        self.edge_scorers = nn.ModuleDict()
        for edge_type in data.edge_types:
            key = "__".join(edge_type)
            self.edge_scorers[key] = nn.Linear(2 * hidden, 1)

    def forward(self, data):
        # ---------- Encode ----------
        x_dict = {
            ntype: self.node_encoders[ntype](data[ntype].x)
            for ntype in data.node_types
        }

        # ---------- Message passing ----------
        for layer in self.hgt_layers:
            x_dict = layer(x_dict, data.edge_index_dict)

        # ---------- A) Feature reconstruction ----------
        recon_dict = {
            ntype: self.node_decoders[ntype](x_dict[ntype])
            for ntype in data.node_types
        }

        feat_err = {
            ntype: F.mse_loss(
                recon_dict[ntype],
                data[ntype].x,
                reduction="none"
            ).mean(dim=1)
            for ntype in data.node_types
        }

        # ---------- B) Edge reconstruction ----------
        edge_err = {ntype: torch.zeros(
            data[ntype].num_nodes,
            device=data[ntype].x.device
        ) for ntype in data.node_types}

        for edge_type in data.edge_types:
            src, _, dst = edge_type
            key = "__".join(edge_type)
            edge_index = data[edge_type].edge_index

            h_src = x_dict[src][edge_index[0]]
            h_dst = x_dict[dst][edge_index[1]]
            logits = self.edge_scorers[key](torch.cat([h_src, h_dst], dim=1)).squeeze()

            # BCE loss assuming observed edges = 1
            loss = F.binary_cross_entropy_with_logits(
                logits,
                torch.ones_like(logits),
                reduction="none"
            )

            # normalize by degree
            edge_err[dst] += scatter_add(
                loss,
                edge_index[1],
                dim=0,
                dim_size=data[dst].num_nodes
            )

        # ---------- C) Neighbor deviation (degree-normalized) ----------
        struct_err = {ntype: torch.zeros_like(feat_err[ntype]) for ntype in data.node_types}

        for edge_type in data.edge_types:
            src, _, dst = edge_type
            edge_index = data[edge_type].edge_index

            neighbor_mean = scatter_mean(
                x_dict[src][edge_index[0]],
                edge_index[1],
                dim=0,
                dim_size=data[dst].num_nodes
            )

            valid = neighbor_mean.abs().sum(dim=1) > 0
            diff = F.mse_loss(
                x_dict[dst][valid],
                neighbor_mean[valid],
                reduction="none"
            ).mean(dim=1)

            struct_err[dst][valid] += diff

        # ---------- Final anomaly score ----------
        anomaly_score = {
            ntype: 0.4 * feat_err[ntype] + 0.3 * edge_err[ntype] + 0.3 * struct_err[ntype]
            for ntype in data.node_types
        }

        return anomaly_score, feat_err, edge_err, struct_err
