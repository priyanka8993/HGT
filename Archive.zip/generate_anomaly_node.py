def get_pharmacy_info(anomaly_idx, pharmacy_mapping, pharmacy_labels):

    new_idx_mapping = pd.read_csv("filtered_node_mapping.csv")
    old_node_idx = (new_idx_mapping['node_type'] == 'pharmacy') & (new_idx_mapping['new_index'] == anomaly_idx)
    node_id = new_idx_mapping.loc[old_node_idx, 'old_index'].values[0]
    current_idx = pharmacy_mapping['pharmacy'] == node_id

    pharmacy_id = str(pharmacy_mapping.loc[current_idx,'pharmacy_enc'].to_list()[0])
    print(node_id)
    print(pharmacy_id)
    # pattern = re.compile(r'^0*' + re.escape(str(pharmacy_id)) + r'$')
    # pharmacy_info_row = pharmacy_labels[pharmacy_labels['ncpdp_id'].astype(str).str.match(pattern)]


    return node_id, pharmacy_id