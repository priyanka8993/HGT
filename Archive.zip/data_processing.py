import os
import pandas as pd
import torch
from torch_geometric.data import HeteroData
import json
import numpy as np
from torch_geometric.transforms import ToUndirected
import torch_geometric
from sklearn.preprocessing import StandardScaler
import torch

def filter_invalid_pharmacies(hetero_data, threshold_ratio=0.9):
    """
    Creates a new HeteroData where:
      - pharmacy nodes with majority-zero features are dropped
      - their edges are removed
      - other nodes not connected to surviving pharmacies are also removed
    
    Returns:
        new_data (HeteroData): filtered graph
        mapping (dict): mapping[node_type] = tensor (old idx -> new idx, -1 if dropped)
    """
    new_data = HeteroData()
    mapping = {}

    # === Step 1: Identify pharmacies to keep ===
    pharmacy_x = hetero_data['pharmacy'].x
    nonzero_counts = (pharmacy_x != 0).sum(dim=1)

    threshold = int(pharmacy_x.size(1) * threshold_ratio)
    keep_pharm_mask = nonzero_counts > threshold
    keep_pharm_nodes = keep_pharm_mask.nonzero(as_tuple=True)[0]

    # Mapping: old → new for pharmacies
    pharm_map = -torch.ones(pharmacy_x.size(0), dtype=torch.long)
    pharm_map[keep_pharm_nodes] = torch.arange(keep_pharm_nodes.size(0))
    mapping["pharmacy"] = pharm_map

    # === Step 2: Track connected nodes ===
    connected_nodes = {ntype: set() for ntype in hetero_data.node_types}
    connected_nodes["pharmacy"] = set(keep_pharm_nodes.tolist())

    for edge_type in hetero_data.edge_types:
        src, rel, dst = edge_type
        edge_index = hetero_data[edge_type].edge_index

        mask = torch.ones(edge_index.size(1), dtype=torch.bool)
        if src == "pharmacy":
            mask &= keep_pharm_mask[edge_index[0]]
        if dst == "pharmacy":
            mask &= keep_pharm_mask[edge_index[1]]

        edge_index = edge_index[:, mask]
        connected_nodes[src].update(edge_index[0].tolist())
        connected_nodes[dst].update(edge_index[1].tolist())

    # === Step 3: Build mappings for each node type ===
    for ntype in hetero_data.node_types:
        # Robust num_nodes inference
        old_num = hetero_data[ntype].num_nodes
        if old_num is None:
            if hasattr(hetero_data[ntype], "x") and hetero_data[ntype].x is not None:
                old_num = hetero_data[ntype].x.size(0)
            else:
                # infer from edges
                max_idx = -1
                for edge_type in hetero_data.edge_types:
                    src, rel, dst = edge_type
                    edge_index = hetero_data[edge_type].edge_index
                    if src == ntype:
                        max_idx = max(max_idx, edge_index[0].max().item())
                    if dst == ntype:
                        max_idx = max(max_idx, edge_index[1].max().item())
                old_num = max_idx + 1

        keep_mask = torch.zeros(old_num, dtype=torch.bool)
        keep_mask[list(connected_nodes[ntype])] = True
        keep_nodes = keep_mask.nonzero(as_tuple=True)[0]

        node_map = -torch.ones(old_num, dtype=torch.long)
        node_map[keep_nodes] = torch.arange(keep_nodes.size(0))
        mapping[ntype] = node_map

        # assign features (if present)
        if hasattr(hetero_data[ntype], "x") and hetero_data[ntype].x is not None:
            new_data[ntype].x = hetero_data[ntype].x[keep_mask]
        new_data[ntype].num_nodes = keep_nodes.size(0)

    # === Step 4: Filter edges ===
    for edge_type in hetero_data.edge_types:
        src, rel, dst = edge_type
        edge_index = hetero_data[edge_type].edge_index
        edge_attr = getattr(hetero_data[edge_type], "edge_attr", None)

        src_map, dst_map = mapping[src], mapping[dst]

        mask = (src_map[edge_index[0]] != -1) & (dst_map[edge_index[1]] != -1)
        edge_index = edge_index[:, mask]
        if edge_attr is not None:
            edge_attr = edge_attr[mask]

        edge_index = torch.stack([
            src_map[edge_index[0]],
            dst_map[edge_index[1]]
        ], dim=0)

        new_data[edge_type].edge_index = edge_index
        if edge_attr is not None:
            new_data[edge_type].edge_attr = edge_attr

    return new_data, mapping


def save_node_mapping(node_mapping):
    
    # Flatten the mapping dictionary into a dataframe
    rows = []
    for ntype, tensor_map in node_mapping.items():
        for old_idx, new_idx in enumerate(tensor_map.tolist()):
            rows.append({"node_type": ntype, "old_index": old_idx, "new_index": new_idx})
    
    df_mapping = pd.DataFrame(rows)
    
    # Save to CSV
    csv_file = "filtered_node_mapping.csv"
    df_mapping.to_csv(csv_file, index=False)
    
    print(f"Node mapping saved to {csv_file}")

    return df_mapping

def scale_heterodata_all(data):
    """
    Standardize node features and edge attributes for all node and edge types
    in a HeteroData object.
    """
    # Scale node features
    for ntype in data.node_types:
        x = data[ntype].x
        if x is not None:
            x_np = x.cpu().numpy()
            scaler = StandardScaler()
            x_scaled = scaler.fit_transform(x_np)
            data[ntype].x = torch.tensor(x_scaled, dtype=torch.float, device=x.device)
    
    # Scale edge attributes
    for edge_type in data.edge_types:
        if hasattr(data[edge_type], 'edge_attr') and data[edge_type].edge_attr is not None:
            edge_attr = data[edge_type].edge_attr
            edge_np = edge_attr.cpu().numpy()
            scaler = StandardScaler()
            edge_scaled = scaler.fit_transform(edge_np)
            data[edge_type].edge_attr = torch.tensor(edge_scaled, dtype=torch.float, device=edge_attr.device)
    
    return data

def check_heterodata(data: HeteroData):
    """
    Sanity checks to avoid silent bugs
    """
    print("=== HeteroData Summary ===")
    print("Node types:", data.node_types)
    print("Edge types:", data.edge_types)

    for ntype in data.node_types:
        assert hasattr(data[ntype], "x"), f"{ntype} missing x"
        print(f"{ntype}: x={data[ntype].x.shape}")

    for etype in data.edge_types:
        assert hasattr(data[etype], "edge_index"), f"{etype} missing edge_index"
        print(f"{etype}: edges={data[etype].edge_index.shape[1]}")

    print("==========================\n")


def replace_na_to_zero(data):
    ## Replace NaNs with 0. 


    # --- Replace NaNs across all node feature tensors ---
    for node_type in data.node_types:
        if 'x' in data[node_type] and torch.is_floating_point(data[node_type].x):
            data[node_type].x = torch.nan_to_num(data[node_type].x, nan=0.0)
    
    # --- Replace NaNs across all edge type feature tensors ---
    for edge_type in data.edge_types:
        if 'edge_attr' in data[edge_type] and data[edge_type].edge_attr is not None:
            if torch.is_floating_point(data[edge_type].edge_attr):
                data[edge_type].edge_attr = torch.nan_to_num(data[edge_type].edge_attr, nan=0.0)
    return data
