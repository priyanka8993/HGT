import torch
import pandas as pd
from copy import deepcopy
import numpy as np



def remove_single_edge(hetero_data, rel, edge_id, device):
    new_data = deepcopy(hetero_data)

    edge_index = new_data[rel].edge_index
    mask = torch.ones(edge_index.size(1), dtype=torch.bool, device=device)
    mask[edge_id] = False

    new_data[rel].edge_index = edge_index[:, mask]

    if hasattr(new_data[rel], "edge_attr") and new_data[rel].edge_attr is not None:
        new_data[rel].edge_attr = new_data[rel].edge_attr[mask]

    return new_data



import torch
import pandas as pd

@torch.no_grad()
def node_feature_explainability(
    model,
    data,
    node_type,
    node_idx,
    feature_names=None,
    device="cpu"
):
    """
    Causal node feature explainability using feature masking.

    Returns a DataFrame:
    feature | contribution | original_value
    """
    model.eval()
    data = data.to(device)

    # ---- Baseline anomaly ----
    anomaly, feat_err, edge_err, struct_err = model(data)
    base_score = anomaly[node_type][node_idx].item()

    # Copy original features
    x = data[node_type].x
    num_features = x.size(1)

    # Feature statistics (mean replacement)
    feature_mean = x.mean(dim=0)

    contributions = []

    for f in range(num_features):
        print(f)
        # Backup original value
        orig_val = x[node_idx, f].item()

        # Mask feature
        x[node_idx, f] = feature_mean[f]

        # Recompute anomaly
        anomaly_masked, _, _, _ = model(data)
        masked_score = anomaly_masked[node_type][node_idx].item()

        # Contribution
        contrib = base_score - masked_score

        contributions.append({
            "feature": feature_names[f] if feature_names else f"f_{f}",
            "contribution": contrib,
            "original_value": orig_val
        })

        # Restore original value
        x[node_idx, f] = orig_val

    df = pd.DataFrame(contributions)
    df = df.sort_values("contribution", ascending=False).reset_index(drop=True)

    return df

import copy
import pandas as pd
import torch

# @torch.no_grad()
# def edge_type_explainability(
#     model,
#     data,
#     node_type,
#     node_idx,
#     device="cpu"
# ):
#     """
#     Causal edge-type explainability by removing relations.

#     Returns:
#     relation | contribution | num_edges_removed
#     """
#     model.eval()
#     data = data.to(device)

#     # ---- Baseline ----
#     anomaly, feat_err, edge_err, struct_err = model(data)
#     base_score = anomaly[node_type][node_idx].item()
    
#     results = []

#     for rel in data.edge_types:
#         src, etype, dst = rel

#         # Copy graph
#         data_mod = copy.deepcopy(data)

#         edge_index = data_mod[rel].edge_index
#         if node_type == src:
#             mask = edge_index[0] != node_idx
#         elif node_type == dst:
#             mask = edge_index[1] != node_idx
#         else:
#             continue

#         removed = (~mask).sum().item()
#         if removed == 0:
#             continue

#         # Remove edges touching node
#         data_mod[rel].edge_index = edge_index[:, mask]

#         # Recompute anomaly
#         anomaly_new, _, _, _ = model(data_mod)
#         new_score = anomaly_new[node_type][node_idx].item()
#         print(base_score, new_score)
#         results.append({
#             "relation": rel,
#             "contribution": base_score - new_score,
#             "num_edges_removed": removed
#         })

#     df = pd.DataFrame(results)
#     df = df.sort_values("contribution", ascending=False).reset_index(drop=True)

#     return df

def get_node_attribute_diff(hetero_data, node_type, node_idx, node_attr_description, feat_names):
    """Compare a node’s features to population statistics."""
    x = hetero_data[node_type].x.cpu().numpy()
    
    this_feat = x[node_idx]
    pop_mean, pop_median, pop_std = x.mean(axis=0), np.median(x, axis=0), x.std(axis=0) + 1e-6
    
    diff = this_feat - pop_median
    z = (this_feat - pop_mean) / pop_std

    # Get business-friendly feature descriptions
    feat_desc = [node_attr_description[f] for f in feat_names]
    
    return pd.DataFrame({
        "Anomaly value": this_feat,
        "Population mean": pop_mean,
        "Population median": pop_median,
        "Population std": pop_std,
        "diff_vs_median": diff,
        "zscore": z
    }, index=feat_desc)


import torch
import pandas as pd
from collections import defaultdict

import torch
import pandas as pd
from copy import deepcopy


@torch.no_grad()
def edge_type_explainability_causal(
    model,
    data,
    node_type,
    node_idx,
    device="cpu"
):
    """
    Causal edge-type explainability via intervention:
    measures change in anomaly score when each relation is removed.
    """
    model.eval()
    data = data.to(device)

    # ----- Baseline -----
    anomaly, feat_err, edge_err, struct_err = model(data)
    base_score = anomaly[node_type][node_idx].item()
    print(base_score)
    rows = []

    for rel in data.edge_types:
        src, _, dst = rel
        # if dst != node_type:
        #     continue


        edge_index = data[rel].edge_index
        mask = edge_index[1] == node_idx
        num_neighbors = mask.sum().item()
        print(rel, num_neighbors)

        if num_neighbors == 0:
            continue

        # ----- Clone graph -----
        data_perturbed = deepcopy(data)
        print(data_perturbed.edge_types)

        # Remove ONLY edges pointing to this node
        keep = ~mask
        data_perturbed[rel].edge_index = edge_index[:, keep]
        print(data_perturbed.edge_types)

        
        # ----- Forward -----
        anomaly_p,feat_err_p, edge_err_p, struct_err_p= model(data_perturbed)
        new_score = anomaly_p[node_type][node_idx].item()
        print(edge_err, edge_err_p)
        rows.append({
            "relation": rel,
            "num_neighbors": num_neighbors,
            "base_score": base_score,
            "score_without_relation": new_score,
            "contribution": base_score - new_score
        })

    df = pd.DataFrame(rows)
    if df.empty:
        return df

    # Normalize
    total = df["contribution"].abs().sum()
    df["normalized_contribution"] = df["contribution"] / (total + 1e-9)

    return df.sort_values("normalized_contribution", ascending=False)


import copy
import pandas as pd
import torch


@torch.no_grad()
def edge_type_explainability(
    model,
    data,
    node_type,
    node_idx,
    device="cpu"
):
    """
    Causal edge-type explainability by removing ALL edges
    of a relation connected to the target node.

    Returns:
        relation | contribution | num_edges_removed
    """
    model.eval()
    # data = data.to(device)

    # ----- Baseline -----
    anomaly, feat_err, edge_err, struct_err = model(data)
    base_score = anomaly[node_type][node_idx].item()

    results = []

    for rel in data.edge_types:
        src, _, dst = rel

        # Only relations touching the node
        if node_type not in (src, dst):
            continue

        # Copy graph
        data_cf = copy.deepcopy(data)

        edge_index = data_cf[rel].edge_index

        # Remove all edges involving node_idx
        if node_type == src:
            mask = edge_index[0] != node_idx
        else:
            mask = edge_index[1] != node_idx

        removed = (~mask).sum().item()
        if removed == 0:
            continue

        data_cf[rel].edge_index = edge_index[:, mask]

        # Recompute anomaly
        anomaly_cf, feat_err_cf, edge_err_cf, struct_err_cf = model(data_cf)
        new_score = anomaly_cf[node_type][node_idx].item()
        print(base_score, new_score)
        
        results.append({
            "relation": rel,
            "contribution": base_score - new_score,
            "num_edges_removed": removed
        })

    df = pd.DataFrame(results)
    df = df.sort_values("contribution", ascending=False).reset_index(drop=True)

    # Optional normalization
    if not df.empty:
        df["normalized_contribution"] = df["contribution"] / df["contribution"].sum()

    return df

