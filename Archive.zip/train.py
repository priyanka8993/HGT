# train.py
import torch
from torch.optim import Adam
from model import HeteroHGTAnomaly


def train(model, data, epochs=100, lr=1e-3, device="cuda"):
    model = model.to(device)
    data = data.to(device)

    optimizer = Adam(model.parameters(), lr=lr)

    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()

        anomaly_score, feat_err, edge_err, struct_err = model(data)

        # Self-supervised objective
        loss = 0
        for ntype in data.node_types:
            loss += feat_err[ntype].mean()
            loss += edge_err[ntype].mean()
            loss += struct_err[ntype].mean()

        loss.backward()
        optimizer.step()

        if epoch % 10 == 0:
            print(f"Epoch {epoch:03d} | Loss {loss.item():.4f}")

    return model
