# evaluate.py
import torch
from model import HeteroHGTAnomaly


@torch.no_grad()
def evaluate(model, data, top_k=10):
    model.eval()
    anomaly_score, feat_err, edge_err, struct_err = model(data)

    results = {}

    for ntype in data.node_types:
        scores = anomaly_score[ntype]
        if ntype == 'pharmacy' and top_k > 20:
            top_idx = torch.topk(scores, top_k).indices
            results[ntype] = {
                "top_nodes": top_idx.cpu(),
                "scores": scores[top_idx].cpu(),
                "feature_err": feat_err[ntype][top_idx].cpu(),
                "edge_err": edge_err[ntype][top_idx].cpu(),
                "struct_err": struct_err[ntype][top_idx].cpu(),
            }
        else: 
            top_k = 20
            top_idx = torch.topk(scores, top_k).indices
            results[ntype] = {
                "top_nodes": top_idx.cpu(),
                "scores": scores[top_idx].cpu(),
                "feature_err": feat_err[ntype][top_idx].cpu(),
                "edge_err": edge_err[ntype][top_idx].cpu(),
                "struct_err": struct_err[ntype][top_idx].cpu(),
            }
 

    return results
