import psycopg2 as pg
from psycopg2 import sql
import pandas as pd
import numpy as np
import seaborn as sns
import pandas.io.sql as sqlio
import math
import warnings
import boto3, json
import redshift_connector
from datetime import datetime as dt
from sqlalchemy import create_engine
warnings.filterwarnings('ignore')

import torch
from torch_geometric.data import HeteroData



### Getting Secret Manager credentials for data read from Redshift

def get_rs_secret(secret_id, region):
    """Fetching Secret value for adm_turbo_sys_acc_secret"""
    print("Get Secret in function")
    sm_client = boto3.client("secretsmanager", region_name=region)
    secret = sm_client.get_secret_value(
        SecretId=secret_id)
    params = json.loads(secret['SecretString'])
    return params

def get_db_cred(secret_id, region):
    """Fetching Secret value for adm_turbo_sys_acc_secret"""
    print("Get Secret in function")
 
    sm_client = boto3.client("secretsmanager", region_name=region)
    secret = sm_client.get_secret_value(
        SecretId=secret_id)
    params = json.loads(secret['SecretString'])
    return params

def set_db_connection(region, db_name, user, password):

    # db_secret_name = 'adm_turbo_sys_acc_secret',
    # account_name = 'AdmTurboAccName',
    # account_pwd = 'AdmTurboAccSecret'
    # rs_details = get_rs_secret(db_secret_name, region)
    # adm_turbo_rw_user = rs_details.get(account_name)
    # adm_turbo_rw_password = rs_details.get(account_pwd)

    iris_host = 'iris-edb-prd.carpdwnmaayt.us-east-2.redshift.amazonaws.com'
    bia_host = 'cwb-rs-cluster-prod.czywitd0zinp.us-east-2.redshift.amazonaws.com'

    #Creating redshift connection tunnel
    if db_name == 'iris_db':
        conn = pg.connect(dbname=db_name,
                      host= iris_host,
                      port=5439,
                      user=user,
                      password=password,
                      sslmode = 'require')
    elif db_name == 'bia_db':
        conn = pg.connect(dbname=db_name,
                      host= bia_host,
                      port=5439,
                      user=user,
                      password=password,
                      sslmode = 'require')

    return conn

def read_db_data(query, conn):

    data = sqlio.read_sql_query(query, conn)
    return data

## Replace NaNs with 0. 

def replace_nans(hetero_data):
    
    # --- Replace NaNs across all node and edge feature tensors ---
    for node_type in hetero_data.node_types:
        if 'x' in hetero_data[node_type] and torch.is_floating_point(hetero_data[node_type].x):
            hetero_data[node_type].x = torch.nan_to_num(hetero_data[node_type].x, nan=0.0)
    
    for edge_type in hetero_data.edge_types:
        if 'edge_attr' in hetero_data[edge_type] and hetero_data[edge_type].edge_attr is not None:
            if torch.is_floating_point(hetero_data[edge_type].edge_attr):
                hetero_data[edge_type].edge_attr = torch.nan_to_num(hetero_data[edge_type].edge_attr, nan=0.0)
    return hetero_data



